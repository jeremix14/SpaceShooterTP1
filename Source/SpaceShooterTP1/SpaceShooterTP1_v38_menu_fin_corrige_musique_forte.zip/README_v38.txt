v38

CORRECTIONS DU MENU DE FIN
- Suppression complète de « CHOISISSEZ LA SUITE ».
- Panneau plus compact.
- REJOUER et RETOUR AU MENU sont maintenant entièrement à l'intérieur du panneau.
- Les zones cliquables correspondent exactement aux boutons dessinés.
- Score sans zéros inutiles conservé.
- Vague atteinte conservée.

MUSIQUE
- Volume C++ : 0.22 -> 0.72.
- Nouveau WAV beaucoup plus fort.
- Importer S_MusiqueFond_v38_PLUS_FORTE.wav dans Content/Audio.
- Remplacer l'ancien asset puis le renommer exactement S_MusiqueFond.
- Cocher Looping sur l'asset si désiré.

FICHIERS À REMPLACER
- SpaceShipPawn.cpp
- SpaceShooterHUD.cpp
